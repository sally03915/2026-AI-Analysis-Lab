## 📅 4개월차 2주차: 고급 RAG 에이전트 (GraphRAG 및 자율 검색 에이전트)

> **[지난 주차 연계 브리핑]**
> * **1주차 핵심:** 키워드 검색(BM25)과 벡터 유사도 검색을 결합한 하이브리드 검색(`EnsembleRetriever`)과 크로스 인코더 기반의 리랭킹(Reranking)을 통해 RAG의 검색 정확도 한계를 극복했습니다.
> * **2주차 연계:** 고정된 문서를 단순히 찾아오는 단계를 넘어, 방대한 기업 문서 간의 **관계망(Knowledge Graph)**을 구축하여 복잡한 다중 홉(Multi-hop) 질문에 답변하는 **GraphRAG 및 자율 검색 에이전트** 아키텍처를 학습합니다.
> 
> 

---

## 📘 [이론 마크다운] `04_Advanced_GraphRAG_and_Agentic_RAG.md`

# 4개월차 2주차: GraphRAG와 자율 검색 에이전트(Agentic RAG) 설계

## 📌 1. 학습 목표

* 일반 RAG가 문맥의 파편화로 인해 놓치기 쉬운 전체적이고 유기적인 정보(글로벌 요약 및 개체 간 관계)를 그래프 구조로 해결하는 **GraphRAG**의 개념을 이해한다.
* 사용자의 모호한 질문을 분석하여 에이전트가 직접 검색 쿼리를 수정하고, 추가 검색이 필요한지 판단하는 **Agentic RAG(자율 검색 에이전트)** 루프를 구현한다.
* 랭체인 및 그래프 기반 탐색 알고리즘을 활용한 실무형 지식 탐색 파이프라인을 구축한다.

## ⏱️ 2. 시간 배정 (총 3시간 / 180분 기준)
| 시간대           | 소요 시간 | 활동 내용 |
|------------------|-----------|-----------|
| **00:00 ~ 00:50** | 50분 | **이론**: GraphRAG와 Agentic RAG 아키텍처 딥다이브 <br> - 전통적 RAG의 구조적 한계와 개체(Entity)-관계(Relation) 중심 지식 그래프의 필요성 <br> - 에이전트가 스스로 검색 실패를 감지하고 쿼리를 재작성하는 Self-RAG 및 Corrective-RAG 개념 <br> - 멀티 홉(Multi-hop) 질문 추론 메커니즘의 이해 |
| **00:50 ~ 01:00** | 10분 | **쉬는 시간** |
| **01:00 ~ 01:50** | 50분 | **실습 1 & 2**: 엔티티 추출 시뮬레이션 및 Self-RAG 기반 자율 검색 에이전트 노드 구현 <br> - 문서에서 주요 키워드와 인물/조직 관계를 추출하는 파이프라인 실습 <br> - 검색 결과의 연관성을 에이전트가 자체 채점하고 재검색하는 로직 구현 |
| **01:50 ~ 02:00** | 10분 | **쉬는 시간** |
| **02:00 ~ 03:00** | 50분 | **실습 3**: [미션] 복합 질의 대응이 가능한 GraphRAG 스타일의 자율 검색 에이전트 마스터 앱 완성 <br> - 복잡한 사내 조직 및 프로젝트 연관성 질의에 대해 스스로 추론하고 답변을 도출하는 통합 미션 수행 |

---

## 📖 3. 핵심 이론 집중 강의안 (50분 분량)

### 1) 왜 GraphRAG인가? (파편화된 지식의 연결)

* **기존 벡터 RAG의 사각지대:** 문서를 잘게 쪼개(Chunking) 벡터화하다 보니, "A 부서의 프로젝트와 B 부서의 예산안이 미치는 연쇄적 영향"처럼 문서 전반에 걸친 종합적이고 구조적인 관계를 파악하기 어려움.
* **GraphRAG 패러다임:** 텍스트에서 주요 개체(Entity, 예: 사람, 부서, 시스템)와 이들 간의 관계(Relation)를 추출하여 네트워크 그래프 형태로 지식을 구축. 이를 통해 고차원적인 군집 요약 및 다중 홉(Multi-hop) 추론이 가능해짐.

---

### 2) Agentic RAG와 Self-RAG의 동작 원리

* **수동적 검색의 한계:** 한 번 검색해 가져온 문맥에 정답이 없어도 LLM이 억지로 답변을 지어내거나(환각) 대답을 포기하는 현상 발생.
* **자율 검색 에이전트(Agentic RAG):** 검색된 문맥이 질문에 답하기에 충분한지 에이전트가 스스로 평가(`Grader`). 부족하다면 검색 키워드를 자동 보정하여 웹이나 벡터 DB를 재검색(Self-Correction)하는 능동적 아키텍처.

---

## 💻 [코랩 실습 노트북] `04_Advanced_GraphRAG_Master.py`

```python
# ==============================================================================
# 🚀 4개월차 2주차: GraphRAG 및 자율 검색 에이전트(Agentic RAG) 실습 마스터 템플릿
# ==============================================================================
# [수강생 안내] 본 코드는 문서에서 핵심 엔티티 관계를 구조화하고, 
# 에이전트가 검색 결과의 적절성을 스스로 판단해 재검색하는 Self-RAG 루프를 검증합니다.

# 1. 의존성 패키지 설치 (코랩 환경 실행 시 주석 해제)
# !pip install -q langchain==0.2.14 langchain-openai==0.1.20 langchain-core==0.2.33 python-dotenv==1.0.1

import os
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_core.pydantic_v1 import BaseModel, Field

print("📦 GraphRAG 및 자율 검색 에이전트 라이브러리 임포트 완료")

# API Key 설정 관리
if "OPENAI_API_KEY" not in os.environ:
    os.environ["OPENAI_API_KEY"] = "sk-proj-YOUR_MOCK_KEY_FOR_CLASS"

# ==============================================================================
# [실습 1 & 2] 엔티티 관계 추출 및 자율 검색 평가 루프 구성 (강사 시간: 100분)
# ==============================================================================
llm_agentic_engine = ChatOpenAI(model="gpt-4o-mini", temperature=0.0)

def simulate_entity_relation_extraction(document_text: str):
    """
    텍스트 문서에서 주요 개체(Entity)와 이들 간의 관계(Relation)를 추출하는 GraphRAG 전처리 시뮬레이션
    """
    print(f"🕸️ [GraphRAG 전처리] 문서 내 개체 및 관계 구조화 분석 중...")
    
    extraction_prompt = ChatPromptTemplate.from_template(
        """
        다음 문서 내용을 분석하여 주요 개체(Entity)들과 그들 간의 관계(Relation)를 핵심 위주로 요약해줘:
        [문서 내용]
        {doc}
        """
    )
    chain = extraction_prompt | llm_agentic_engine | StrOutputParser()
    return chain.invoke({"doc": document_text})


# ==============================================================================
# [실습 3] [미션] Self-RAG 기반 검색 결과 적절성 자가 진단 에이전트 구현 (강사 시간: 50분)
# ==============================================================================
class SearchGradeResponse(BaseModel):
    is_relevant: str = Field(description="검색된 문서가 질문에 답변하기에 적합한지 여부 (YES 또는 NO)")
    reason: str = Field(description="판단한 이유에 대한 간략한 설명")

def evaluate_retrieved_context_relevance(user_query: str, retrieved_context: str) -> str:
    """
    에이전트가 검색된 문맥이 유효한지 스스로 검사하는 Self-RAG 채점 로직
    """
    print(f"\n🕵️ [Self-RAG 에이전트] 검색된 문맥의 유효성 검사(Relevance Grading) 수행 중...")
    
    grading_prompt = ChatPromptTemplate.from_template(
        """
        사용자의 질문과 검색된 문서 조각을 비교하여, 해당 문서 조각이 질문에 답변하는 데 유용한 정보가 포함되어 있는지 평가하세요.
        - 질문: {query}
        - 검색된 문서: {context}
        
        결과를 YES 또는 NO 형식으로 판단하고 사유를 함께 적어주세요.
        """
    )
    
    grading_chain = grading_prompt | llm_agentic_engine | StrOutputParser()
    result = grading_chain.invoke({"query": user_query, "context": retrieved_context})
    return result

# 시뮬레이션 테스트 실행
sample_doc = "클라우드 인프라 팀의 김철수 리더는 AWS 마이그레이션 프로젝트를 총괄하고 있으며, 보안 규정 SEC-402를 준수해야 합니다."
sample_query = "클라우드 마이그레이션 프로젝트 책임자는 누구인가요?"

print(f"\n🔍 [사용자 쿼리]: {sample_query}")
graph_structure_result = simulate_entity_relation_extraction(sample_doc)
print(f"📊 [추출된 GraphRAG 지식 구조]:\n{graph_structure_result}")

self_rag_evaluation = evaluate_retrieved_context_relevance(sample_query, sample_doc)
print(f"\n⚖️ [Self-RAG 자가 진단 결과]:\n{self_rag_evaluation}")

print("\n✅ [4개월차 2주차 검증 완료] GraphRAG 관계 구조화 및 Self-RAG 자율 에이전트의 검색 검증 로직이 성공적으로 구현되었습니다.")

```