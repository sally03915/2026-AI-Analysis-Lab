## 📅 3개월차 1주차: 멀티모달(Vision & Audio) LLM 활용과 에이전트(Agent) 아키텍처 개론

> **[지난 주차 요약 및 연계 브리핑]**
> * **2개월차 핵심:** LangChain LCEL 파이프라인, Chroma DB 기반 RAG 구축, Streamlit Cloud 웹 앱 프로덕션 배포 및 듀얼 트랙 교안 최적화를 완료했습니다.
> * **3주차 연계:** 3개월차에는 텍스트 기반 대화를 넘어 이미지와 음성을 동시에 이해하는 멀티모달 LLM(GPT-4o 등)을 다루고, LLM이 스스로 판단하고 도구를 선택하여 실행하는 **AI 에이전트(Agent) 아키텍처**의 세계로 진입합니다.
> 
> 

---

## 📘 [이론 마크다운] `03_Multimodal_and_Agent_Architecture.md`

# 3개월차 1주차: 멀티모달 LLM과 자율형 AI 에이전트 아키텍처 설계

## 📌 1. 학습 목표

* 텍스트 중심의 LLM 활용을 넘어 이미지, 오디오 등의 비정형 데이터를 입력받아 처리하는 멀티모달(Multimodal) 프롬프트 엔지니어링 기법을 익힌다.
* AI가 단순 응답을 넘어 외부 도구(Tool/Function)를 스스로 선택하고 실행하는 에이전트(Agent)의 동작 원리를 이해한다.
* LangChain의 `AgentExecutor`와 도구 바인딩(`bind_tools`) 개념을 활용하여 실무형 지능형 에이전트 초안을 작성한다.

## ⏱️ 2. 시간 배정 (총 3시간 / 180분 기준)

| 시간대           | 소요 시간 | 활동 내용 |
|------------------|-----------|-----------|
| **00:00 ~ 00:50** | 50분 | **이론**: 멀티모달 LLM 아키텍처 및 자율형 AI 에이전트 개념 딥다이브 <br> - GPT-4o 등 멀티모달 모델의 시각/청각 토큰화 처리 원리 <br> - LLM의 한계를 극복하는 ReAct(Reasoning + Acting) 프레임워크 <br> - 툴 유틸리티(Tool Calling)와 에이전트 루프의 이해 |
| **00:50 ~ 01:00** | 10분 | **쉬는 시간** |
| **01:00 ~ 01:50** | 50분 | **실습 1 & 2**: 멀티모달 이미지 분석 및 커스텀 툴 바인딩 에이전트 구현 <br> - 이미지 데이터를 Base64로 인코딩하여 LLM에 전달하는 파이프라인 구축 <br> - 파이썬 함수를 에이전트가 직접 호출하도록 바인딩하는 실습 |
| **01:50 ~ 02:00** | 10분 | **쉬는 시간** |
| **02:00 ~ 03:00** | 50분 | **실습 3**: [미션] 사내 데이터 조회 및 계산 기능을 수행하는 자율형 툴 에이전트 완성 <br> - 사용자의 자연어 질문을 분석해 필요한 도구를 스스로 고르고 결과를 조합하는 미션 수행 |


---

## 📖 3. 핵심 이론 집중 강의안 (50분 분량)

### 1) 텍스트를 넘어선 멀티모달(Multimodal) AI의 패러다임

* **기존 텍스트 LLM의 한계:** 과거에는 이미지를 설명하려면 별도의 OCR 모델이나 이미지 Captioning 모델을 거쳐 텍스트로 변환한 뒤 LLM에 넣어야 했음.
* **네이티브 멀티모달(GPT-4o 등):** 텍스트, 이미지, 오디오 토큰을 동일한 신경망 공간에서 동시에 처리하므로 시각적 맥락(차트의 추세, UI 화면의 오류 등)을 직접 이해하고 추론 가능.

---

### 2) AI 에이전트(Agent)와 ReAct 프레임워크

* **에이전트란?:** 사용자의 지시를 받아 "생각(Thought) -> 행동(Action) -> 관찰(Observation)"의 루프를 반복하며 스스로 문제를 해결하는 자율형 프로그램.
* **Tool Calling(도구 사용):** LLM 단독으로는 실시간 날씨나 사내 DB 조회를 할 수 없으므로, 검색 엔진이나 계산기 함수를 '도구'로 쥐여주어 필요할 때 꺼내 쓰도록 유도하는 기술.

---

## 💻 [코랩 실습 노트북] `03_Multimodal_and_Agent_Master.py`

```python
# ==============================================================================
# 🚀 3개월차 1주차: 멀티모달 이미지 분석 및 커스텀 툴 에이전트 실습 마스터 템플릿
# ==============================================================================
# [수강생 안내] 본 코드는 이미지 데이터를 입력받는 멀티모달 추론과, 
# LLM이 직접 파이썬 함수(Tool)를 호출하는 에이전트 아키텍처를 검증합니다.

# 1. 의존성 패키지 설치 (코랩 환경 실행 시 주석 해제)
# !pip install -q langchain==0.2.14 langchain-openai==0.1.20 langchain-core==0.2.33 python-dotenv==1.0.1

import os
import base64
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_core.tools import tool

print("📦 멀티모달 및 에이전트 실습 라이브러리 임포트 완료")

# API Key 설정 관리
if "OPENAI_API_KEY" not in os.environ:
    os.environ["OPENAI_API_KEY"] = "sk-proj-YOUR_MOCK_KEY_FOR_CLASS"

# ==============================================================================
# [실습 1] 멀티모달 Vision 모델 활용 시뮬레이션 (강사 시간: 50분)
# ==============================================================================
llm_multimodal_engine = ChatOpenAI(model="gpt-4o-mini", temperature=0.0)

def simulate_vision_analysis(image_url_or_path: str, user_question: str):
    """
    이미지 경로와 질문을 받아 멀티모달 모델을 통해 분석 결과를 반환합니다.
    """
    print(f"👁️ [Vision 분석 중] 대상 이미지: {image_url_or_path}")
    
    # 텍스트와 이미지 메시지를 결합한 멀티모달 프롬프트 구성 예시
    vision_prompt = ChatPromptTemplate.from_messages([
        ("system", "당신은 전문 시스템 UI/UX 및 데이터 시각화 분석가입니다. 제공된 시각 자료를 바탕으로 상세히 분석해주세요."),
        ("user", [
            {"type": "text", "text": user_question},
            {"type": "image_url", "image_url": {"url": image_url_or_path}}
        ])
    ])
    
    chain = vision_prompt | llm_multimodal_engine | StrOutputParser()
    return chain

# 가상의 이미지 URL을 통한 멀티모달 실행 테스트 시뮬레이션
mock_image_url = "https://upload.wikimedia.org/wikipedia/commons/thumb/d/d7/Desktop_computer_clipart_-_Yellow.svg/512px-Desktop_computer_clipart_-_Yellow.svg.png"
# result_vision = simulate_vision_analysis(mock_image_url, "이 이미지에 나타난 기기의 주요 구성 요소를 설명해줘.")
# print(result_vision)


# ==============================================================================
# [실습 2 & 3] 커스텀 툴(Tool) 정의 및 에이전트 바인딩 미션 (강사 시간: 100분)
# ==============================================================================
print("\n=== [현업 실무 미션] 사내 데이터 조회를 위한 커스텀 툴 에이전트 구축 ===")

# 1. @tool 데코레이터를 이용한 커스텀 도구 정의 (LLM이 함수의 이름과 Docstring을 읽고 직접 호출 판단)
@tool
def get_employee_stock_options(employee_name: str) -> str:
    """
    특정 임직원의 사내 스톡옵션 부여 현황 및 잔여 수량을 조회합니다.
    Args:
        employee_name (str): 조회할 임직원의 성명
    """
    # 가상의 사내 DB 데이터 매핑
    database = {
        "김철수": "스톡옵션 1,200주 (행사가격 15,000원, 잔여 2년)",
        "이영희": "스톡옵션 3,500주 (행사가격 12,000원, 잔여 1년)"
    }
    return database.get(employee_name, f"'{employee_name}'에 해당하는 임직원 정보를 찾을 수 없습니다.")

@tool
def calculate_estimated_bonus(performance_score: int) -> str:
    """
    업무 성과 점수(0~100점)를 입력받아 예상 인센티브 지급액을 계산합니다.
    Args:
        performance_score (int): 임직원의 연간 성과 점수
    """
    if performance_score >= 90:
        return "인센티브 지급액: 기본급의 300% (S등급)"
    elif performance_score >= 80:
        return "인센티브 지급액: 기본급의 200% (A등급)"
    else:
        return "인센티브 지급액: 기본급의 100% (B등급 이하)"

# 2. LLM에 도구(Tools) 바인딩 수행
available_tools = [get_employee_stock_options, calculate_estimated_bonus]
llm_with_tools = llm_multimodal_engine.bind_tools(available_tools)

print("🛠️ LLM 모델에 커스텀 툴 바인딩 완료 (등록된 툴 개수: 2개)")

# 3. 에이전트 실행 테스트 시뮬레이션
test_agent_query = "김철수 사원의 스톡옵션 현황을 조회해 주고, 성과 점수 92점일 때 인센티브가 얼마인지도 계산해 줘."
print(f"\n🗣️ 사용자 질문: {test_agent_query}")

ai_response = llm_with_tools.invoke(test_agent_query)
print(f"🤖 AI 에이전트 툴 호출 판단 결과 (Tool Calls):\n{ai_response.tool_calls}")
print("\n✅ [3개월차 1주차 검증 완료] 멀티모달 환경 이해 및 에이전트의 자율 툴 셀렉션 로직이 정상 작동합니다.")

```